#!/bin/sh
echo -ne '\033c\033]0;Hook_My_Cube\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/Hook_My_Cube.x86_64" "$@"
